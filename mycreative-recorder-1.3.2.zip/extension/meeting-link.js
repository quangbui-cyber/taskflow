/** Shared by the extension and server: compare room identity, never passcodes/query strings. */
export const MEETING_TAB_PATTERNS = [
  "https://meet.google.com/*",
  "https://teams.microsoft.com/*",
  "https://teams.live.com/*",
  "https://teams.cloud.microsoft/*",
  "https://zoom.us/*",
  "https://*.zoom.us/*",
  "https://zoom.com/*",
  "https://*.zoom.com/*",
];

/** @param {string | null | undefined} input */
export function parseMeetingLink(input) {
  if (!input) return null;
  let url;
  try {
    url = new URL(input);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" || url.username || url.password || url.port) return null;
  const host = url.hostname.toLowerCase();
  let path;
  try {
    path = decodeURIComponent(url.pathname);
  } catch {
    return null;
  }
  if (host === "meet.google.com") {
    const match = /^\/(?:lookup\/|_meet\/)?([a-z]{3}-[a-z]{4}-[a-z]{3}|[a-z]{10})\/?$/i.exec(path);
    if (!match) return null;
    const letters = match[1].toLowerCase().replace(/-/g, "");
    const id = `${letters.slice(0, 3)}-${letters.slice(3, 7)}-${letters.slice(7)}`;
    return { provider: "google", label: "Google Meet", id, key: `google:${id}`, url: url.href };
  }
  if (["teams.microsoft.com", "teams.live.com", "teams.cloud.microsoft"].includes(host)) {
    let hash;
    try {
      hash = decodeURIComponent(url.hash.slice(1));
    } catch {
      return null;
    }
    // Link mời, link rút gọn, link nằm trong #fragment, trang "pre-join", hoặc link bọc trong launcher (?url=...)
    const launcher = url.searchParams.get("url") || "";
    let launcherPath = "";
    try {
      launcherPath = decodeURIComponent(launcher);
    } catch {
      launcherPath = launcher;
    }
    const sources = [path, hash, launcherPath];
    let id = null;
    for (const source of sources) {
      const match = /(?:^|\/)l\/meetup-join\/([^/?]+)/.exec(source)
        || /(?:^|\/)meet\/([^/?]+)/.exec(source)
        || /(?:^|\/)pre-join-calling\/([^/?]+)/.exec(source);
      if (match) {
        id = match[1];
        break;
      }
    }
    id = id || url.searchParams.get("threadId");
    // Free/personal Teams IDs are a separate namespace from work/school meetings.
    const namespace = host === "teams.live.com" ? "personal" : "work";
    if (id && /^(?:\d{8,20}|19:[a-zA-Z0-9_+=.@-]+)$/.test(id)) {
      return { provider: "teams", label: "Microsoft Teams", id, key: `teams:${namespace}:${id}`, url: url.href };
    }
    // Đang họp trên Teams web: tab chỉ là /v2/ hoặc /_#/... không chứa mã cuộc họp. Vẫn cho ghi,
    // đánh dấu generic để không bị coi là "rời họp" khi URL đổi giữa chừng.
    if (/^\/(?:v2|_|dl)(?:\/|$)/.test(path)) {
      return { provider: "teams", label: "Microsoft Teams", id: "web", key: `teams:${namespace}:web`, url: url.href, generic: true };
    }
    return null;
  }
  if (/^(?:[a-z0-9-]+\.)*zoom\.(?:us|com)$/.test(host)) {
    const match = /^\/(?:j|s)\/(\d{9,11})\/?$/.exec(path)
      || /^\/wc\/(?:join\/)?(\d{9,11})(?:\/(?:join|start))?\/?$/.exec(path);
    if (!match) {
      // Phòng cá nhân: zoom.us/my/<tên>
      const personal = /^\/my\/([a-z0-9._-]{2,64})\/?$/i.exec(path);
      if (!personal) return null;
      const name = personal[1].toLowerCase();
      return { provider: "zoom", label: "Zoom", id: name, key: `zoom:my:${name}`, url: url.href };
    }
    const id = match[1];
    return { provider: "zoom", label: "Zoom", id, key: `zoom:${id}`, url: url.href };
  }
  return null;
}

/** @param {ReturnType<typeof parseMeetingLink>} link */
export function meetingLinkTitle(link) {
  return link ? `Họp ${link.label} (${link.provider === "teams" ? "tức thì" : link.id})` : "Cuộc họp tức thì";
}
